﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Web;
using Microsoft.AspNet.SignalR;

namespace WebApplication4.Hubs
{
    public class ChatHub : Hub
    {
        public static List<string> users = new List<string>();

        public void Send(string name, string message)
        {
            Clients.Group("Group1").addNewMessage(name, message);

            //Clients.All.addNewMessage(name, message);
        }

        public override Task OnConnected()
        {
            List<string> data = new List<string>
            {
                "Test message 1",
                "Test message 2",
                "Test message 3"
            };

            foreach (var item in data)
            {
                Clients.All.addNewMessage("Person", item);
            }

            users.Add(Context.ConnectionId);
            Groups.Add(Context.ConnectionId, "Group1");


            return base.OnConnected();
        }

        public override Task OnReconnected()
        {
            users.Remove(Context.ConnectionId);
            Groups.Remove(Context.ConnectionId, "Group1");

            return base.OnReconnected();
        }
    }
}